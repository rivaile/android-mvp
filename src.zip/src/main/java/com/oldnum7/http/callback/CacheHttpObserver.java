package com.oldnum7.http.callback;

import io.reactivex.annotations.NonNull;

/**
 * <pre>
 *       author : denglin
 *       time   : 2017/09/08/18:54
 *       desc   : 实现缓存的回调...
 *       version: 1.0
 * </pre>
 */
public class CacheHttpObserver<T> extends HttpObserver<T> {

    @Override
    public void onNext(@NonNull T t) {

    }
}
