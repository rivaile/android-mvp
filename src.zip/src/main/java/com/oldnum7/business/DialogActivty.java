package com.oldnum7.business;

import android.os.Bundle;

import com.oldnum7.R;
import com.oldnum7.mvp.base.BaseActivity;

/**
 * <pre>
 *       author : denglin
 *       time   : 2017/09/19/14:20
 *       desc   :
 *       version: 1.0
 * </pre>
 */
public class DialogActivty extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog);
    }
}
