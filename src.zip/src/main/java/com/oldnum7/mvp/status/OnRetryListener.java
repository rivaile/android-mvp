package com.oldnum7.mvp.status;


public interface OnRetryListener {

    void onRetry();
}
