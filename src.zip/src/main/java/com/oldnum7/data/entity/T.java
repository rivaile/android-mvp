package com.oldnum7.data.entity;

/**
 * <pre>
 *       author : denglin
 *       time   : 2017/09/06/11:19
 *       desc   :
 *       version: 1.0
 * </pre>
 */
public class T {
}
